<?php

namespace frontend\controllers;
use Yii;
use yii\db\Schema;
use frontend\tbhome\DatabaseTool;
use frontend\tbhome\Curl;
//$frontend=dirname(__DIR__);
class UpdateController extends DbController
{
    public $layout='user';

    public function init(){
        parent::init();
        if(Yii::$app->user->identity->role!==100){
            Yii::$app->session->setFlash('danger', '您不是管理员！');
            $this->redirect(['/user/index']);
        }
    }

    private function getVersion(){
        $table='sys';
        $sql="SELECT * FROM {{%$table}} WHERE id=1";
        $sys=Yii::$app->db->createCommand($sql)->queryOne();
        return $sys['version'];
    }

    public function actionIndex(){
        header('Content-Type:text/html;charset=UTF-8');
        ini_set("max_execution_time", "1800");
        $frontend=Yii::getAlias('@frontend');
        $table='sys';
        $sql="SELECT * FROM {{%$table}} WHERE id=1";
        $sys=Yii::$app->db->createCommand($sql)->queryOne();
        $version=$sys['version'];

        if(Yii::$app->request->isPost){


            if(!isset($sys['version'])){
                //        $this->renameColumn('{{%usermodule}}', 'module_satus', 'module_status');


                require $frontend.'/update.php';


            }elseif($sys['version']==1.10){

                //$version=
                //   echo '您的系统已升级成功！版本：1.10，请勿重复升级！';

                $backFilename=$frontend.'/backup/'.date('Ymd_His',time());
                $updateZip=$frontend.'/runtime/'.date('Ymd_His',time());
                $updateFilesArr=$this->updateFilesArr();
                $update=$frontend.'/update/update_v'.strval($version).'.php';
                 echo $update;


                if(!$updateFilesArr){
                    echo '恭喜！您的系统已是最新版本，无需升级！';
                }else{
                    $this->backupFiles($backFilename);
                    //     if($this->actionBackupdb()){  }
                    $this->downloadUpdatefiles($updateZip.'.zip');

                    \frontend\tbhome\FileTools::extractZip($updateZip.'.zip', $frontend);
                    echo '<br/>升级文件成功！<br>';
                    foreach($updateFilesArr as $dir){echo '<br>'.$dir;}
                    unlink($updateZip.'.zip');

                    if(is_file($update)){
                        echo '<br/>升级数据库<br/>';
                        require $update;
                    }


                }




















            }elseif($sys['version']<1.0){//手动清除版本信息，重新升级


                require $frontend.'/update.php';

            }else{



                echo 'version字段已设置！';
            }

        }

        //   $this->update('{{%user}}', ['longitude'=>116.473259, 'latitude'=>39.86954], ['uid'=>1]);

    }


    public function updateFilesArr(){
        $filesMd5=\frontend\tbhome\FileTools::filesMd5Arr();
        $checkDiffApi='http://demo.vcards.top/vcardsdemo/frontend/web/index.php?r=api/update/checkdiff';
        $curl = new Curl();
        $diffFiles = $curl->setOption(
            CURLOPT_POSTFIELDS,
            http_build_query($filesMd5)
        )->post($checkDiffApi);
        $diffFiles=json_decode($diffFiles,true) ? json_decode($diffFiles,true) : false;
        if($diffFiles){
            $updateFiles=array();
            foreach($diffFiles as $key=>$value){
                //   $updateFiles=array_merge($updateFiles,$key);
                $updateFiles[]=$key;
            }
            return $updateFiles;
        }else{
            return false;
        }


    }

    private function downloadUpdatefiles($dir){

        $updateFilesArr=$this->updateFilesArr();

        $updateFilesApi='http://demo.vcards.top/vcardsdemo/frontend/web/index.php?r=api/update/updatefiles';

        $version=$this->getVersion();
        $postData=[
            'version'=>$version,
            'files'=>$updateFilesArr,
        ];

        $ch = curl_init($updateFilesApi);
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        $fp = fopen($dir, "wb");
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $res=curl_exec($ch);
        curl_close($ch);
        fclose($fp);
        return $res;

        /*
        foreach($updateFilesArr as $updateFile){
            $postData=[
                'version'=>$version,
                'file'=>$updateFile,
        ];
            $diffFiles = $curl->setOption(
                CURLOPT_POSTFIELDS,
                http_build_query($postData)
            )->post($updateFilesApi);
            echo $diffFiles;
        }
*/


    }


    public function actionBackupdb(){
        if(Yii::$app->request->isPost){
            $frontend=Yii::getAlias('@frontend');
            $backFilename=$frontend.'/backup/'.date('Ymd_His',time());

            $dsn=Yii::$app->db->dsn;
            $username=Yii::$app->db->username;
            $password=Yii::$app->db->password;
            $piecesDSN = explode(';', $dsn);//把字符串打散成数组，分割号：
            $host=explode('=', $piecesDSN[0]);
            $host=$host[1];
            $dbname=explode('=', $piecesDSN[1]);
            $dbname=$dbname[1];

            $sqlFile=$backFilename.'.sql';
            $config = array(
                'host' => $host,
                'port' => 3306,
                'user' => $username,
                'password' => $password,
                'database' => $dbname,
                'charset' => 'utf-8',
                'target' => $sqlFile//'sql.sql'//
            );

            $dbtool=new DatabaseTool($config);
            if($dbtool->backup()){
                return true;
            }
        }

    }

    protected function backupFiles($backFilename){
        $frontend=Yii::getAlias('@frontend');
        $updateFilesArr=$this->updateFilesArr();
        $zip = new \ZipArchive();
        if ($zip->open($backFilename.'.zip', \ZipArchive::CREATE) === TRUE) {
            //新建时必须为CREATE, OVERWRITE为覆盖，不可用。
            foreach($updateFilesArr as $value){
                $eachFile=$frontend.'/'.$value;
                $zip->addFile($eachFile);
            }
            $zip->close(); //关闭处理的zip文件
        }
        echo '<br/>本地差量文件备份成功：<br/>'.$backFilename.'.zip';
        return $updateFilesArr;
    }

    public function actionClearv(){
        if(Yii::$app->request->isPost){
            $this->update('{{%sys}}', ['version'=>0.00], ['id'=>1]);
            echo '<br/>版本号已清除！请刷新查看！';
        }
    }

}
