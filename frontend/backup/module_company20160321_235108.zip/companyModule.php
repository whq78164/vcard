<?php

namespace frontend\modules\company;

class companyModule extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\company\controllers';
   // public $defaultRoute='company';

    public function init()
    {
        parent::init();

        // custom initialization code goes here////
    }
}
